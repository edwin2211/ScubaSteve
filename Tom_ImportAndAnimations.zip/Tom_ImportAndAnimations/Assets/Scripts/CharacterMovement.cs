﻿using UnityEngine;
using System.Collections;

public class CharacterMovement : MonoBehaviour {
	public Animator anim;
	public float walkSpeed;
	public float JumpSpeed = 100;




	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator>();
	}

	// Update is called once per frame
	void Update () {


		//RunRight
		if(Input.GetKey(KeyCode.D)){
			anim.SetBool("Run", true);
		} 
		//RunLeft
		else if(Input.GetKey(KeyCode.A)){
			anim.SetBool("Run", true);
		} else {
			anim.SetBool("Run", false);
		}
		//Hit
		if (Input.GetKeyDown (KeyCode.Mouse0)) {
			anim.SetBool ("Hit", true);
		} else {
			anim.SetBool ("Hit", false);
		}




	}
}
